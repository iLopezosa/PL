import java.io.*;
/** Clase principal */
class Prueba {
 /** Medodo main */
 public static void main(String argv[]) {
 /*
        Aqui va el codigo
 */
 System.out.println("Los comentarios se escriben /* asi */");
 /* // */
 //  /**  */
 }
} // class